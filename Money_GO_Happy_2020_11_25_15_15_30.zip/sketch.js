var monkey, stone, banana, scene, ground, score;
var monkey_image , stone_image , banana_image , scene_image;

function preload(){
  
monkey_image=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
 
stone_image = loadImage("stone.png");

banana_image = loadImage("banana.png");  
  
scene_image = loadImage("jungle.jpg");  
}

function setup() {
  createCanvas(400, 400);
  background("white");
  
  scene = createSprite(200,190,20,20);
  scene.addImage(scene_image);
  scene.velocityx = -3;
  scene.scale = 0.5;
 
  ground = createSprite(200,350,400,20);
  ground.x = ground.width/2;
  ground.velocityx = -2;
  ground.visible = false;
  
  monkey = createSprite(50,300,20,20);
  monkey.addAnimation("running",monkey_image);
  monkey.scale = 0.15; 
  
  
  stones();
  bananas();
  
  score = 0;
  
}

function draw() {
  background(220);
  
  monkey.collide(ground);
  
 if(keyDown("space")){
   monkey.velocityY = -8;
 } 
  
  monkey.velocityY = monkey.velocityY + 0.8;
  
  if(monkey.isTouching(banana)){
    score = score + 2;
    banana.destroy();
  }
    
//(monkey.isTouching(stone)){
 //onkey.velocityX = 0;

  
  
  drawSprites();
   text(score,350,280);
}

function stones(){
  stone= createSprite(400,10,20,20);
  stone.addImage(stone_image);
  stone.velocity = -2;
  stone.scale = 0.5;
 
}

function bananas(){
 if(frameCount % 20 === 0){ 
  banana = createSprite(350,180,20,20);
  banana.addImage(banana_image);
  banana.scale = 0.05;
  banana.velocityX = -2;
 }
}






